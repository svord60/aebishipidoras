import os
import json
import gzip
import base64
import io
import asyncio
from pathlib import Path

from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext
from PIL import Image, ImageDraw, ImageFont

# ================== НАСТРОЙКИ ==================
TOKEN = "8018150951:AAE6MdTxrd-8UHUOPMmCufwqWf_86ph-gjw"  # ТВОЙ ТОКЕН
TEMPLATES_FOLDER = "templates"

bot = Bot(token=TOKEN)
dp = Dispatcher(storage=MemoryStorage())

# ================== СОСТОЯНИЯ ==================
class States(StatesGroup):
    waiting_for_name = State()

# ================== ФУНКЦИЯ РИСОВАНИЯ ==================
def draw_text_on_image(image_bytes, text):
    """Рисует текст по центру картинки"""
    img = Image.open(io.BytesIO(image_bytes)).convert("RGBA")
    
    # Создаем слой для текста
    txt_layer = Image.new('RGBA', img.size, (255, 255, 255, 0))
    draw = ImageDraw.Draw(txt_layer)
    
    # Шрифт
    try:
        font = ImageFont.truetype("arial.ttf", 40)
    except:
        font = ImageFont.load_default()
    
    # Центрируем текст
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    x = (img.width - text_width) // 2
    y = (img.height - text_height) // 2
    
    # Рисуем текст с тенью
    draw.text((x+3, y+3), text, font=font, fill=(0, 0, 0, 180))
    draw.text((x, y), text, font=font, fill=(255, 255, 255, 255))
    
    # Объединяем
    result = Image.alpha_composite(img, txt_layer)
    
    # Сохраняем
    out = io.BytesIO()
    result.convert("RGB").save(out, format='PNG')
    return out.getvalue()

# ================== ПОИСК ФАЙЛОВ ==================
def find_template_files():
    """Ищет файлы в папке templates/emodz_1"""
    template_dir = Path(TEMPLATES_FOLDER) / "emodz_1"
    
    if not template_dir.exists():
        return None
    
    # Ищем файлы
    files = {}
    for ext in ['*.png', '*.lottie', '*.tgs']:
        found = list(template_dir.glob(ext))
        if found:
            files[ext.replace('*', '')] = str(found[0])
    
    return files

# ================== СОЗДАНИЕ СТИКЕРА ==================
async def create_sticker_with_name(text):
    """Создает TGS файл с именем"""
    
    # Находим файлы
    files = find_template_files()
    if not files:
        raise Exception("Файлы не найдены в templates/emodz_1")
    
    # Берем LOTTIE файл (или TGS если нет LOTTIE)
    lottie_file = files.get('.lottie')
    if not lottie_file:
        raise Exception("Нет LOTTIE файла")
    
    # Читаем LOTTIE
    with open(lottie_file, 'r', encoding='utf-8') as f:
        lottie_data = json.load(f)
    
    # Ищем картинку в LOTTIE
    image_found = False
    for asset in lottie_data.get('assets', []):
        if 'p' in asset and asset['p'].startswith('data:image'):
            # Извлекаем картинку
            base64_data = asset['p'].split(',')[1]
            img_bytes = base64.b64decode(base64_data)
            
            # Рисуем текст
            new_img = draw_text_on_image(img_bytes, text)
            
            # Кодируем обратно
            new_base64 = base64.b64encode(new_img).decode('utf-8')
            asset['p'] = f"data:image/png;base64,{new_base64}"
            image_found = True
            break
    
    if not image_found:
        raise Exception("В LOTTIE файле нет картинки")
    
    # Сохраняем во временный TGS
    out = io.BytesIO()
    with gzip.open(out, 'wb') as f:
        f.write(json.dumps(lottie_data).encode('utf-8'))
    
    temp_file = f"temp_{hash(text)}.tgs"
    with open(temp_file, 'wb') as f:
        f.write(out.getvalue())
    
    return temp_file

# ================== КОМАНДЫ БОТА ==================
@dp.message(Command("start"))
async def start(message: types.Message, state: FSMContext):
    # Проверяем наличие файлов
    files = find_template_files()
    if not files:
        await message.answer("❌ Ошибка: нет файлов в папке templates/emodz_1")
        return
    
    # Отправляем превью (PNG)
    png_file = files.get('.png')
    if png_file:
        with open(png_file, 'rb') as f:
            await message.answer_photo(
                types.BufferedInputFile(f.read(), filename="preview.png"),
                caption="👋 Выбран эмодзи №1\n✍️ Напиши имя для стикера:"
            )
    else:
        await message.answer("✍️ Напиши имя для стикера:")
    
    await state.set_state(States.waiting_for_name)

@dp.message(States.waiting_for_name)
async def get_name(message: types.Message, state: FSMContext):
    name = message.text.strip()
    
    if len(name) > 20:
        await message.answer("❌ Слишком длинное имя! Максимум 20 символов.")
        return
    
    # Отправляем статус
    await bot.send_chat_action(message.chat.id, "upload_document")
    
    try:
        # Создаем стикер с именем
        tgs_file = await create_sticker_with_name(name)
        
        # Отправляем результат
        await message.answer_document(
            FSInputFile(tgs_file),
            caption=f"✅ Готово! Твой стикер с именем {name}"
        )
        
        # Удаляем временный файл
        os.remove(tgs_file)
        
    except Exception as e:
        await message.answer(f"❌ Ошибка: {str(e)}")
    
    await state.clear()
    
    # Кнопка "Ещё"
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🔄 Создать ещё", callback_data="again")]
        ]
    )
    await message.answer("Хочешь ещё?", reply_markup=keyboard)

@dp.callback_query(F.data == "again")
async def again(callback: types.CallbackQuery, state: FSMContext):
    await state.clear()
    await start(callback.message, state)
    await callback.answer()

# ================== ЗАПУСК ==================
async def main():
    print("🤖 Бот запускается...")
    
    # Проверяем наличие папки и файлов
    files = find_template_files()
    if files:
        print("✅ Найдены файлы:")
        for ext, path in files.items():
            print(f"   - {os.path.basename(path)}")
    else:
        print("❌ НЕТ ФАЙЛОВ в папке templates/emodz_1!")
        print("📁 Положи туда:")
        print("   - *.png")
        print("   - *.lottie")
        print("   - *.tgs")
        return
    
    print("\n🚀 Бот готов! Напиши /start")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())